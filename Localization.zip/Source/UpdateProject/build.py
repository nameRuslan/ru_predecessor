"""Rebuild the Russian Predecessor 1.17 resource from supplied files and reviewed edits.

Python 3.10+, standard library only:
    python build.py --output-dir OUTPUT
"""
from pathlib import Path
import argparse
import collections
import hashlib
import json
import shutil
import struct
import zipfile

from editor import ROOT, NEW, OLD, RUSSIAN, OLD_BY_KEY, RU_BY_KEY, EN, REFS, DELTA, load_edits, check
from locres import Reader, parse, replace_strings


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def compile_resource(english_bytes, targets):
    """Keep the complete new English key/hash structure; split shared strings as needed."""
    doc = parse(english_bytes)
    groups = collections.defaultdict(dict)
    for entry, target in zip(doc['entries'], targets):
        groups[entry['index']].setdefault(target['russian'], []).append(target)
    table = [{'text': s['text'], 'source_index': i, 'refs': 0}
             for i, s in enumerate(doc['strings'])]
    indices = []
    mapping = {}
    for index in range(len(doc['strings'])):
        # The first variant stays at its source index. Other contexts get new rows.
        for n, (text, entries) in enumerate(groups[index].items()):
            out_index = index if n == 0 else len(table)
            row = {'text': text, 'source_index': index, 'refs': len(entries)}
            if n == 0:
                table[index] = row
            else:
                table.append(row)
            mapping[index, text] = out_index
    for entry, target in zip(doc['entries'], targets):
        indices.append(mapping[entry['index'], target['russian']])

    prefix = bytearray(english_bytes[:doc['string_offset']])
    reader = Reader(english_bytes)
    reader.take(16)
    reader.value('B')
    reader.value('q')
    reader.value('I')
    offsets = []
    for _ in range(reader.value('I')):
        reader.value('I')
        reader.string()
        for _ in range(reader.value('I')):
            reader.value('I')
            reader.string()
            reader.value('I')
            offsets.append(reader.pos)
            reader.value('i')
    assert reader.pos == doc['string_offset'] and len(offsets) == len(indices)
    for pos, index in zip(offsets, indices):
        struct.pack_into('<i', prefix, pos, index)
    data = prefix + struct.pack('<I', len(table))
    for row in table:
        encoded = row['text'].encode('utf-16le') + b'\0\0'
        data += struct.pack('<i', -(len(encoded) // 2)) + encoded + struct.pack('<i', row['refs'])
    # Prove that only string-index fields changed in the source prefix.
    restored = bytearray(prefix)
    for pos, entry in zip(offsets, doc['entries']):
        struct.pack_into('<i', restored, pos, entry['index'])
    assert restored == english_bytes[:doc['string_offset']]
    return bytes(data), table, indices


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output-dir', type=Path, default=ROOT / 'output')
    args = ap.parse_args()
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    english = (ROOT / 'inputs/Game-EN_1.17.locres').read_bytes()
    old_english = (ROOT / 'inputs/Game-EN_previous.locres').read_bytes()
    old_russian = (ROOT / 'inputs/Game-RU_v3.locres').read_bytes()
    assert sha(english) == '251bf685deea5061b2fa758a4d1c6931bca2b01e5eb77ce3f9cea12ba1dc59ed'
    assert sha(old_english) == 'a6e81ecda0fff038031410f67de984e04edf0c7174e35173d6a4f81012e07030'
    assert sha(old_russian) == 'c8a16c7d99e2e18656d0e9ac94195af00032cd9fb2b1da4565a4ab9dd31fcce7'
    assert all(e['source_hash'] == OLD_BY_KEY[k]['source_hash'] for k, e in RU_BY_KEY.items())
    edits = load_edits()
    assert not check(edits), check(edits)
    assert not ({e['index'] for e in DELTA} - edits.keys()), 'Unreviewed source change'
    policy = json.loads((ROOT / 'name-policy.json').read_text())
    display_names = set(policy['english_display_names'])
    assert display_names <= set(EN.values())
    previous_names = json.loads((ROOT / 'inputs/english-names-v3.json').read_text())
    names_by_key = {(e['namespace'], e['key']): e['kind'] for e in previous_names['selected_entries']}
    targets = []
    names = []
    chat_labels = []
    checks_done = set()
    for e in NEW['entries']:
        key = e['namespace'], e['key']
        before = OLD_BY_KEY.get(key)
        same_source = before and all(before[k] == e[k] for k in ('text', 'source_hash'))
        if same_source:
            text = RU_BY_KEY[key]['text']
            method = 'preserved-v3'
        else:
            text = edits[e['index']]
            method = 'reviewed-update-1.17'
        if e['index'] in edits:
            text = edits[e['index']]
            method = 'reviewed-v4'
        kind = names_by_key.get(key)
        if e['namespace'] == 'ST_HeroImpaler' and e['key'].endswith('Name'):
            kind = 'hero' if e['key'] == 'DisplayName' else 'hero_ability_or_title'
        if e['namespace'] == 'ST_Impaler_Perks' and e['key'].endswith('Name'):
            kind = 'augment'
        if e['text'] in display_names:
            kind = 'mob_or_buff'
        if kind:
            text = e['text']
            method = 'english-name'
            names.append({'namespace': e['namespace'], 'key': e['key'],
                          'source_index': e['index'], 'english': e['text'], 'kind': kind})
        if e['namespace'] == policy['chat_channel_namespace'] and e['key'].startswith(policy['chat_channel_key_prefix']):
            text = e['text']
            method = 'english-chat-channel'
            chat_labels.append({'namespace': e['namespace'], 'key': e['key'], 'text': text})
        if (e['index'], text) not in checks_done:
            assert not check({e['index']: text}), (key, check({e['index']: text}))
            checks_done.add((e['index'], text))
        targets.append({**e, 'russian': text, 'method': method})

    binary, strings, indices = compile_resource(english, targets)
    result = parse(binary)
    assert len(result['entries']) == len(NEW['entries']) == 10804
    assert result['namespaces'] == NEW['namespaces']
    for original, target, actual in zip(NEW['entries'], targets, result['entries']):
        for key in ('namespace', 'key', 'key_hash', 'source_hash'):
            assert actual[key] == original[key]
        assert actual['text'] == target['russian']
    assert replace_strings(binary, {}) == binary
    new_keys = {(e['namespace'], e['key']) for e in NEW['entries']}
    removed = [e for e in OLD['entries'] if (e['namespace'], e['key']) not in new_keys]
    assert not (new_keys & {(e['namespace'], e['key']) for e in removed})
    added = [e for e in DELTA if (e['namespace'], e['key']) not in OLD_BY_KEY]
    changed = [e for e in DELTA if (e['namespace'], e['key']) in OLD_BY_KEY]
    overrides = [
        {'namespace': e['namespace'], 'key': e['key'], 'source_index': e['index'], 'output_index': oi}
        for e, oi in zip(NEW['entries'], indices) if e['index'] != oi]
    carried = sum(t['method'] == 'preserved-v3' for t in targets)
    modified_existing = sum(
        (t['namespace'], t['key']) in RU_BY_KEY and
        t['russian'] != RU_BY_KEY[t['namespace'], t['key']]['text'] for t in targets)
    output_methods = collections.defaultdict(set)
    for t, i in zip(targets, indices):
        output_methods[i].add(t['method'])
    source_table = {
        'source_sha256': sha(english), 'previous_english_sha256': sha(old_english),
        'previous_russian_sha256': sha(old_russian), 'culture': 'ru-RU',
        'version': 'v4-1.17-Bloodtide-EnglishNames',
        'note': 'Compiled by exact namespace/key from the current English source. source_index is the new English string index. English name/UI contexts use separate records where needed.',
        'strings': [{'index': i, 'source_index': s['source_index'],
                     'english': EN[s['source_index']], 'russian': s['text'],
                     'method': '+'.join(sorted(output_methods[i])) or 'unreferenced-source'}
                    for i, s in enumerate(strings)],
        'entry_overrides': overrides,
    }
    catalog = collections.defaultdict(set)
    for name in names:
        catalog[name['english']].add(name['kind'])
    name_source = {
        'catalog': [{'english': text, 'categories': sorted(kinds)} for text, kinds in sorted(catalog.items())],
        'selected_entries': names, 'chat_channels': chat_labels,
        'split_strings': [{'source_index': s['source_index'], 'new_index': i,
                           'english': EN[s['source_index']], 'translation': s['text']}
                          for i, s in enumerate(strings) if i >= len(NEW['strings'])],
    }
    report = {
        'edition': source_table['version'], 'game_update': '1.17 Bloodtide', 'culture': 'ru-RU',
        'source_sha256': sha(english), 'previous_source_sha256': sha(old_english),
        'baseline_russian_sha256': sha(old_russian), 'output_sha256': sha(binary),
        'bytes': len(binary), 'format_version': result['version'],
        'namespaces': len(result['namespaces']), 'entries': len(result['entries']),
        'source_strings': len(NEW['strings']), 'output_strings': len(strings),
        'added_source_entries': len(added), 'changed_source_entries': len(changed),
        'removed_source_entries': len(removed), 'reviewed_delta_unique_strings': len({e['index'] for e in DELTA}),
        'reviewed_manual_strings': len(edits), 'modified_existing_entries': modified_existing,
        'entries_carried_with_identical_source_and_translation': carried,
        'preserved_name_entries': len(names), 'mob_display_name_entries': sum(n['kind'] == 'mob_or_buff' for n in names),
        'chat_channels': chat_labels, 'split_string_records': len(strings) - len(NEW['strings']),
        'checks': {
            'every_new_and_changed_entry_reviewed': True,
            'all_keys_and_source_hashes_match_current_english': True,
            'all_namespace_hashes_and_entry_order_preserved': True,
            'key_prefix_identical_except_string_indices': True,
            'all_reference_counts_and_indices_valid': True,
            'all_entries_preserve_placeholder_and_rich_text_token_multisets': True,
            'all_entries_preserve_numeric_tokens_and_percent_counts': True,
            'removed_entries_not_carried_forward': True,
            'english_names_and_chat_channels_verified': True,
            'exact_parser_roundtrip': True,
        },
        'known_source_discrepancies': [
            'Valmont Bloodbound in the supplied resource grants Attack Speed; the supplied patch note describes a Slow. The resource was translated as supplied.',
            'Hemophagia HUD says Hero souls restore maximum-Mana percentage instead; the menu says additionally. Both original descriptions were preserved.',
        ],
        'runtime_test': 'File-level validation only; the user previously confirmed ru-RU loading in the game.',
    }
    bundle = ROOT / 'bundle'
    source = bundle / 'Source'
    source.mkdir(parents=True, exist_ok=True)
    locres = bundle / 'Localization/Game/ru-RU/Game.locres'
    locres.parent.mkdir(parents=True, exist_ok=True)
    locres.write_bytes(binary)
    write_json(source / 'strings.en-ru.json', source_table)
    write_json(source / 'english-names.json', name_source)
    write_json(source / 'editorial-edits.json', [
        {'source_index': i, 'english': EN[i], 'russian': text,
         'references': [{'namespace': ns, 'key': key} for ns, key in REFS[i]]}
        for i, text in sorted(edits.items())])
    write_json(source / 'update-diff.json', {
        'added': added,
        'changed': [{'before': OLD_BY_KEY[e['namespace'], e['key']], 'after': e} for e in changed],
        'removed': removed,
    })
    write_json(bundle / 'validation.json', report)
    shutil.copy2(ROOT / 'name-policy.json', source / 'name-policy.json')
    shutil.copy2(ROOT / 'inputs/glossary-ru-v3.json', source / 'glossary-ru.json')
    shutil.copy2(ROOT / 'LICENSE-bslie.txt', bundle / 'LICENSE-bslie.txt')
    readme = f'''PREDECESSOR — РУССИФИКАТОР v4 ДЛЯ 1.17 BLOODTIDE

Обновление на основе нового английского Game.locres, предоставленного 23.09.2026.
За основу взят ваш рабочий вычитанный русский файл v3.

ЧТО ОБНОВЛЕНО
• Обработаны все {len(added)} новых и {len(changed)} изменённых записей исходника.
• Добавлены описания Valmont, его способностей и усилений.
• Обновлены описания Crucible и изменившиеся тексты старых героев и Вечных.
• Названия мобов, боссов и их усилений оставлены на английском, в том числе
  в пингах, заданиях, описаниях и уведомлениях.
• Метки чата: [Global], [Local], [Party], [Team], [Whisper].
  В пояснениях party переведено как «группа».
• Имена героев, предметов и способностей по-прежнему английские.
• Вычитанный перевод неизменившихся описаний сохранён.

КАК УСТАНОВИТЬ ПОВЕРХ РАБОТАЮЩЕЙ РУССКОЙ ВЕРСИИ
1. Полностью закрой игру.
2. Сохрани копию текущего русского Game.locres для отката.
3. Скопируй папку Localization из архива в папку Predecessor\\Content,
   подтвердив замену файла в ru-RU.
   Полный путь при стандартной установке Steam:
   C:\\Program Files (x86)\\Steam\\steamapps\\common\\Predecessor\\Predecessor\\Content\\Localization\\Game\\ru-RU\\Game.locres
4. Запусти игру и оставь выбранным русский язык.

Откат: закрой игру и верни сохранённый русский Game.locres.

ПРОВЕРКА
Готовый файл содержит все {len(result['entries']):,} записей нового исходника.
Ключи и исходные хеши взяты из обновления. Удалённые записи исключены.
Для всех записей проверены переменные, теги, значки, числа и проценты.
Общие строки разделены там, где названию и обычной подписи нужен разный текст.
Сборка проверена на уровне файла. Проверка отображения в самой игре здесь
не проводилась.

Источником игровых формулировок служит предоставленный английский файл.
Он местами расходится с патчноутом: например, Bloodbound описывает бонус
скорости атаки, а патчноут — замедление. В переводе сохранён смысл файла игры.

ИСХОДНИКИ
Source\\strings.en-ru.json — полный текущий английский и русский текст.
Source\\editorial-edits.json — вычитанные строки этого обновления.
Source\\update-diff.json — все изменения английского исходника.
Source\\name-policy.json — правила английских названий и каналов чата.
Source\\UpdateProject — воспроизводимая сборка с исходными файлами.
Для пересборки из этой папки (Python 3.10+, без внешних зависимостей):
  python build.py --output-dir OUTPUT
Правки берутся из edits/*.txt; JSON с полным текстом сам по себе файл не меняет.
validation.json — технический отчёт о проверках.

Сохранены совпадения из перевода bslie/predecessor-rus (MIT).
https://github.com/bslie/predecessor-rus
Copyright (c) 2024 Lie. Лицензия: LICENSE-bslie.txt.

SHA-256 Game.locres:
{sha(binary)}
'''
    (bundle / 'README_RU.txt').write_text(readme, encoding='utf-8-sig', newline='\r\n')
    project = source / 'UpdateProject'
    files = [ROOT / f for f in ('build.py', 'editor.py', 'locres.py', 'name-policy.json', 'LICENSE-bslie.txt')]
    files += [p for subdir in ('inputs', 'edits') for p in (ROOT / subdir).iterdir() if p.is_file()]
    for path in files:
        dest = project / path.relative_to(ROOT)
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, dest)
    archive = output / 'Predecessor_RU_EnglishNames_v4_1.17.zip'
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for path in sorted(bundle.rglob('*')):
            if path.is_file():
                z.write(path, path.relative_to(bundle).as_posix())
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert z.read('Localization/Game/ru-RU/Game.locres') == binary
        assert json.loads(z.read('Source/strings.en-ru.json')) == source_table
        assert json.loads(z.read('validation.json')) == report
    print(json.dumps({'archive': str(archive), 'archive_bytes': archive.stat().st_size,
                      'locres_sha256': sha(binary), 'entries': len(result['entries']),
                      'added': len(added), 'changed': len(changed), 'removed': len(removed),
                      'modified_existing': modified_existing, 'name_entries': len(names),
                      'mob_name_entries': report['mob_display_name_entries'],
                      'chat_channels': len(chat_labels), 'manual_strings': len(edits),
                      'splits': report['split_string_records'], 'validation': 'passed'},
                     ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
