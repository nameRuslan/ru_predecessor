"""Review helpers for the exact English 1.17 source supplied by the user."""
from pathlib import Path
import collections
import json
import re
import sys
from locres import parse

ROOT = Path(__file__).resolve().parent
NEW = parse((ROOT / 'inputs/Game-EN_1.17.locres').read_bytes())
OLD = parse((ROOT / 'inputs/Game-EN_previous.locres').read_bytes())
RUSSIAN = parse((ROOT / 'inputs/Game-RU_v3.locres').read_bytes())
OLD_BY_KEY = {(e['namespace'], e['key']): e for e in OLD['entries']}
RU_BY_KEY = {(e['namespace'], e['key']): e for e in RUSSIAN['entries']}
EN = {i: s['text'] for i, s in enumerate(NEW['strings'])}
REFS = collections.defaultdict(list)
for e in NEW['entries']:
    REFS[e['index']].append((e['namespace'], e['key']))
DELTA = [e for e in NEW['entries'] if (e['namespace'], e['key']) not in OLD_BY_KEY
         or any(e[k] != OLD_BY_KEY[e['namespace'], e['key']][k]
                for k in ('text', 'source_hash'))]
ALIASES = {'Header': 'H', 'EffectText': 'E', 'AbilityPowerText': 'AP',
           'AttackDamageText': 'AD', 'HealthText': 'HP', 'ManaText': 'M',
           'CC_Text': 'CC', 'AbilityName': 'N', 'PassiveItemText': 'P',
           'ActiveItemText': 'A', 'Condition': 'C', 'AbilityPowertext': 'Ap',
           'AttackSpeedText': 'AS'}
TOKEN = re.compile(r'<[^>]*>|\{[^{}]*\}')


def compact(i, text=None):
    source = EN[i]
    text = source if text is None else text
    variables = list(dict.fromkeys(re.findall(r'\{[^{}]*\}', source)))
    tags = list(dict.fromkeys(re.findall(r'<[^>]*>', source)))
    mapping = {v: '{' + str(j) + '}' for j, v in enumerate(variables)}
    for j, t in enumerate(tags):
        mapping[t] = '</>' if t == '</>' else '<' + ALIASES.get(t[1:-1], f't{j}') + '>'
    return TOKEN.sub(lambda m: mapping.get(m[0], m[0]), text), {v: k for k, v in mapping.items()}


def expand(i, text):
    _, mapping = compact(i)
    return TOKEN.sub(lambda m: mapping.get(m[0], m[0]), text)


def load_edits():
    result = {}
    for f in sorted((ROOT / 'edits').glob('*.txt')):
        for m in re.finditer(r'^@@ (\d+)\n(.*?)(?=^@@ \d+\n|\Z)', f.read_text(), re.M | re.S):
            i = int(m[1])
            assert i not in result, (i, 'duplicate', f)
            result[i] = expand(i, m[2].rstrip('\n'))
    return result


def check(edits):
    errors = []
    for i, target in edits.items():
        source = EN[i]
        if collections.Counter(TOKEN.findall(source)) != collections.Counter(TOKEN.findall(target)):
            errors.append((i, 'tokens', list((collections.Counter(TOKEN.findall(source)) - collections.Counter(TOKEN.findall(target))).elements()),
                           list((collections.Counter(TOKEN.findall(target)) - collections.Counter(TOKEN.findall(source))).elements())))
        def numbers(t):
            return collections.Counter(re.findall(r'\d+(?:[.,]\d+)?', TOKEN.sub('', t).replace('seco5nd', 'second')))
        if numbers(source) != numbers(target):
            errors.append((i, 'numbers', dict(numbers(source)), dict(numbers(target))))
        if source.count('%') != target.count('%'):
            errors.append((i, 'percents', source.count('%'), target.count('%')))
    return errors


if __name__ == '__main__':
    edits = load_edits()
    if len(sys.argv) == 1 or sys.argv[1] == 'status':
        print('Edits:', len(edits), 'Errors:', check(edits))
        print('Pending delta:', sorted({e['index'] for e in DELTA} - edits.keys()))
    elif sys.argv[1] == 'show':
        for i in map(int, sys.argv[2].split(',')):
            print('@@', i, REFS[i], '\n' + compact(i)[0])
            if i in edits:
                print('NEW_RU:', compact(i, edits[i])[0])
            else:
                old = set(RU_BY_KEY[k]['text'] for k in REFS[i] if k in RU_BY_KEY)
                print('OLD_RU:', list(old))
            print()
