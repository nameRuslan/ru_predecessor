from pathlib import Path
import collections
import json
import struct

MAGIC = bytes.fromhex('0e147475674a03fc4a15909dc3377f1b')


class Reader:
    def __init__(self, data):
        self.data = data
        self.pos = 0

    def take(self, n):
        assert n >= 0 and self.pos + n <= len(self.data)
        result = self.data[self.pos:self.pos + n]
        self.pos += n
        return result

    def value(self, fmt):
        return struct.unpack('<' + fmt, self.take(struct.calcsize('<' + fmt)))[0]

    def string(self):
        length = self.value('i')
        if length == 0:
            return ''
        raw = self.take(abs(length) * (2 if length < 0 else 1))
        if length < 0:
            assert raw[-2:] == b'\0\0'
            return raw[:-2].decode('utf-16le')
        assert raw[-1:] == b'\0'
        return raw[:-1].decode('utf-8')


def parse(data):
    r = Reader(data)
    assert r.take(16) == MAGIC
    version = r.value('B')
    assert version == 3, version
    string_offset = r.value('q')
    entry_count = r.value('I')
    namespaces = []
    entries = []
    for _ in range(r.value('I')):
        ns_hash = r.value('I')
        ns = r.string()
        count = r.value('I')
        namespaces.append({'name': ns, 'hash': ns_hash, 'count': count})
        for _ in range(count):
            key_hash = r.value('I')
            key = r.string()
            source_hash = r.value('I')
            index = r.value('i')
            entries.append({'namespace': ns, 'key': key, 'key_hash': key_hash,
                            'source_hash': source_hash, 'index': index})
    assert r.pos == string_offset, (r.pos, string_offset)
    assert len(entries) == entry_count
    strings = []
    for _ in range(r.value('I')):
        start = r.pos
        text = r.string()
        refs = r.value('i')
        strings.append({'text': text, 'refs': refs, 'raw': data[start:r.pos]})
    assert r.pos == len(data), (r.pos, len(data))
    counts = collections.Counter(e['index'] for e in entries)
    for i, item in enumerate(strings):
        assert item['refs'] == counts[i], (i, item['refs'], counts[i])
    for item in entries:
        assert 0 <= item['index'] < len(strings)
        item['text'] = strings[item['index']]['text']
    return {'version': version, 'string_offset': string_offset,
            'namespaces': namespaces, 'entries': entries, 'strings': strings}


def replace_strings(original, replacements):
    doc = parse(original)
    result = bytearray(original[:doc['string_offset']])
    result += struct.pack('<I', len(doc['strings']))
    for index, item in enumerate(doc['strings']):
        if index not in replacements:
            result += item['raw']
            continue
        encoded = replacements[index].encode('utf-16le') + b'\0\0'
        result += struct.pack('<i', -(len(encoded) // 2))
        result += encoded
        result += struct.pack('<i', item['refs'])
    return bytes(result)


if __name__ == '__main__':
    root = Path(__file__).resolve().parent
    original = root.parents[1] / 'upload' / 'Game.locres'
    data = original.read_bytes()
    doc = parse(data)
    assert replace_strings(data, {}) == data
    (root / 'english_entries.json').write_text(
        json.dumps(doc['entries'], ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({'bytes': len(data), 'version': doc['version'],
                      'entries': len(doc['entries']), 'strings': len(doc['strings']),
                      'namespaces': len(doc['namespaces']), 'roundtrip': 'exact'}, indent=2))
    print('TOP NAMESPACES', sorted(doc['namespaces'], key=lambda x: -x['count'])[:20])
    wanted = {'play', 'settings', 'heroes', 'store', 'items', 'profile', 'friends',
              'exit', 'quit', 'back', 'apply', 'cancel', 'confirm', 'yes', 'no',
              'gameplay', 'audio', 'video', 'graphics', 'controls', 'language',
              'german', 'deutsch', 'english', 'play game', 'main menu', 'quit game',
              'exit game', 'social', 'collection', 'shop', 'battle pass', 'news',
              'select', 'continue', 'close', 'account', 'accessibility', 'save',
              'interface', 'training', 'practice', 'ranked', 'unranked', 'custom',
              'find match', 'training mode', 'tutorial', 'practice mode'}
    for i, item in enumerate(doc['strings']):
        if item['text'].strip().lower() in wanted:
            refs = [(e['namespace'], e['key']) for e in doc['entries'] if e['index'] == i]
            print(json.dumps({'index': i, 'text': item['text'], 'refs': refs}, ensure_ascii=False))
